//
// Created by seetadev on 2019/10/31.
//

#ifndef SEETAFACE_CLARITYQUALITY_H
#define SEETAFACE_CLARITYQUALITY_H

#include "seeta/Struct.h"

float evaluate_clarity(const SeetaImageData &image, const SeetaRect &info);


#endif //SEETAFACE_CLARITYQUALITY_H
